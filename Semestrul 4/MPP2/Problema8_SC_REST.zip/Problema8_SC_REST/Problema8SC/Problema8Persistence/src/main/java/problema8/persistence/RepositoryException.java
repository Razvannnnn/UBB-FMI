package problema8.persistence;

public class RepositoryException extends RuntimeException {
  public RepositoryException() {
  }

  public RepositoryException(String message) {
    super(message);
  }

  public RepositoryException(String message, Throwable cause) {
    super(message, cause);
  }
}
