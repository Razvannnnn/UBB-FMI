package org.example.reteasocializare;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.example.reteasocializare.Domain.Validators.PrietenieValidator;
import org.example.reteasocializare.Domain.Validators.UtilizatorValidator;
import org.example.reteasocializare.Repository.DB.PrietenieDBRepository;
import org.example.reteasocializare.Repository.DB.UtilizatorDBRepository;
import org.example.reteasocializare.Service.Network;

import java.io.File;
import java.io.IOException;

public class Start extends Application {

    UtilizatorDBRepository utilizatorDBRepository;
    PrietenieDBRepository prietenieDBRepository;
    Network network;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws IOException {
        utilizatorDBRepository = new UtilizatorDBRepository("jdbc:postgresql://localhost:5432/postgres",
                "postgres", "parola", new UtilizatorValidator());
        prietenieDBRepository = new PrietenieDBRepository("jdbc:postgresql://localhost:5432/postgres",
                "postgres", "parola", new PrietenieValidator(utilizatorDBRepository));
        network = new Network(utilizatorDBRepository, prietenieDBRepository);
        initView(stage);
        stage.setTitle("Retea de socializare");
        stage.show();
    }

    private void initView(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(Start.class.getResource("login.fxml"));
        Scene scene = new Scene(loader.load());
        stage.setScene(scene);

        LoginController controller = loader.getController();
        controller.setNetwork(network);
    }
}
