package org.example.reteasocializare;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.example.reteasocializare.Domain.Utilizator;
import org.example.reteasocializare.Domain.UtilizatorCuData;
import org.example.reteasocializare.Service.Network;
import org.example.reteasocializare.Utils.Events.UtilizatorEvent;
import org.example.reteasocializare.Utils.Observable;
import org.example.reteasocializare.Utils.Observer;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class MenuController implements Observer<UtilizatorEvent> {

    private Network network;
    private Utilizator utilizator;
    ObservableList<UtilizatorCuData> model = FXCollections.observableArrayList();;

    @FXML
    TableView<UtilizatorCuData> tableView;

    @FXML
    TableColumn<UtilizatorCuData, String> columnNume;

    @FXML
    TableColumn<UtilizatorCuData, String> columnPrenume;

    @FXML
    TableColumn<UtilizatorCuData, LocalDateTime> columnData;

    @FXML
    Button buttonAddNewFriends;

    @FXML
    Button buttonFriendRequests;

    @FXML
    public void initialize() {
        columnNume.setCellValueFactory(new PropertyValueFactory<>("nume"));
        columnPrenume.setCellValueFactory(new PropertyValueFactory<>("prenume"));
        columnData.setCellValueFactory(new PropertyValueFactory<>("date"));
        columnData.setCellFactory(column -> {
            return new TableCell<UtilizatorCuData, LocalDateTime>() {
                @Override
                protected void updateItem(LocalDateTime item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item == null || empty) {
                        setText(null);
                    } else {
                        setText(item.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm")));
                    }
                }
            };
        });
        tableView.setItems(model);
    }

    public void handleAddNewFriends() {
        try {
            FXMLLoader loader = new FXMLLoader(MenuController.class.getResource("newFriends.fxml"));

            AnchorPane root = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("New Friends");
            dialogStage.initModality(Modality.WINDOW_MODAL);

            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            NewFriendsController newFriendsController = loader.getController();
            newFriendsController.setNetwork(network, utilizator);

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    public void handleDeleteFriend() {
        UtilizatorCuData selected = tableView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            network.removePrietenie(utilizator.getId(), selected.getId());
            initModel();
        }
    }

    public void handleFriendRequests() {
        try {
            FXMLLoader loader = new FXMLLoader(MenuController.class.getResource("friendRequest.fxml"));

            AnchorPane root = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Friend Requests");
            dialogStage.initModality(Modality.WINDOW_MODAL);

            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            FriendRequestController friendRequestController = loader.getController();
            friendRequestController.setNetwork(network, utilizator);

            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    public void initModel() {
        Map<Utilizator, LocalDateTime> utilizatori = network.getCurrentFriendsForUtilizator(utilizator);
        List<UtilizatorCuData> utilizatoriList = utilizatori.entrySet()
                .stream()
                .map(entry -> new UtilizatorCuData(entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());
        model.setAll(utilizatoriList);
    }


    @Override
    public void update(UtilizatorEvent utilizatorEvent) {
        initModel();
    }

    public void setNetwork(Network network, Utilizator utilizator) {
        this.network = network;
        this.utilizator = utilizator;
        network.addObserver(this);
        initModel();
    }
}
