package org.example.reteasocializare.Domain;

import java.text.Format;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Formatter;
import java.util.stream.LongStream;

public class Prietenie extends Entity<Long> {

    LocalDateTime date;

    Long idUser1;
    Long idUser2;
    Integer status;

    public Prietenie(Long idUser1, Long idUser2, Integer status) {
        this.idUser1 = idUser1;
        this.idUser2 = idUser2;
        this.status = status;
        this.date = LocalDateTime.now();
    }

    public Long getIdUtilizator1() {
        return idUser1;
    }

    public Long getIdUtilizator2() {
        return idUser2;
    }

    public Integer getStatus() {
        return status; }

    public Long getId() {
        return super.getId();
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

}
